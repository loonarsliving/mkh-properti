// Service worker minimal - no caching, always fresh
self.addEventListener('fetch', function(event) {
  // Do nothing - let browser handle all requests normally
});
